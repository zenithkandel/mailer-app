<?php
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Cache-Control: no-cache');

$status = [
    'php_version' => PHP_VERSION,
    'imap_loaded' => extension_loaded('imap'),
    'imap_open_exists' => function_exists('imap_open'),
    'imap_functions' => [
        'imap_open' => function_exists('imap_open'),
        'imap_list' => function_exists('imap_list'),
        'imap_status' => function_exists('imap_status'),
    ]
];

if (!function_exists('imap_open')) {
    $status['error'] = 'IMAP extension is not available. Please enable php_imap in php.ini and ensure libc-client.dll is installed.';
}

echo json_encode($status);